from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
import config

def start_keyboard() -> ReplyKeyboardMarkup:
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(f"🧨 Профиль"), KeyboardButton(f"🚀 Накрутка SEO"))
    keyboard.add(KeyboardButton(f"🎈 Информация"))
    keyboard.add(KeyboardButton(f"🩸 Правила"), KeyboardButton(f"❤️ Cаппорт"))
    return keyboard


def more_funcs() -> ReplyKeyboardMarkup:
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(f"🍪 Залив по куку"), KeyboardButton(f"📷 Запись видео + превью"))
    keyboard.add(KeyboardButton(f"📊 SMM-панель"), KeyboardButton(f"📻 Вязка каналов"))
    keyboard.add(KeyboardButton(f"🔙 Вернуться в главное меню"))
    return keyboard


def smm_panel() -> ReplyKeyboardMarkup:
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(f"❤️ Накрутка лайков"), KeyboardButton(f"💬 Накрутка комментариев")).add("👁 Накрутка просмотров")
    keyboard.add(KeyboardButton(f"🔙 Вернуться в главное меню"))
    return keyboard


def likes_accept(link, count, payment_sum) -> InlineKeyboardMarkup:
    yes = InlineKeyboardButton('✅ Да', callback_data=f'likes_accept|{link}|{count}|{payment_sum}|yes')
    no = InlineKeyboardButton('❌ Отменить заказ', callback_data=f'likes_accept|{link}|{count}|{payment_sum}|no')
    keyboard = InlineKeyboardMarkup().add(yes, no)
    return keyboard


def views_accept(link, count, payment_sum) -> InlineKeyboardMarkup:
    yes = InlineKeyboardButton('✅ Да', callback_data=f'views_accept|{link}|{count}|{payment_sum}|yes')
    no = InlineKeyboardButton('❌ Отменить заказ', callback_data=f'views_accept|{link}|{count}|{payment_sum}|no')
    keyboard = InlineKeyboardMarkup().add(yes, no)
    return keyboard


def likes_accept_no() -> InlineKeyboardMarkup:
    no = InlineKeyboardButton('✖️ Вы отменили заказ', callback_data=f'likes_accept_no')
    keyboard = InlineKeyboardMarkup().add(no)
    return keyboard


def likes_accept_yes() -> InlineKeyboardMarkup:
    yes = InlineKeyboardButton('☑️ Вы успешно создали заказ', callback_data=f'likes_accept_yes')
    keyboard = InlineKeyboardMarkup().add(yes)
    return keyboard


def comms_accept(link, comms, payment_sum) -> InlineKeyboardMarkup:
    yes = InlineKeyboardButton('✅ Да', callback_data=f'likes_accept|{link}|{comms}|{payment_sum}|yes')
    no = InlineKeyboardButton('❌ Отменить заказ', callback_data=f'likes_accept|{link}|{comms}|{payment_sum}|no')
    keyboard = InlineKeyboardMarkup().add(yes, no)
    return keyboard


def comms_accept_no() -> InlineKeyboardMarkup:
    no = InlineKeyboardButton('✖️ Вы отменили заказ', callback_data=f'likes_accept_no')
    keyboard = InlineKeyboardMarkup().add(no)
    return keyboard


def comms_accept_yes() -> InlineKeyboardMarkup:
    yes = InlineKeyboardButton('☑️ Вы успешно создали заказ', callback_data=f'likes_accept_yes')
    keyboard = InlineKeyboardMarkup().add(yes)
    return keyboard


def movie_choice() -> InlineKeyboardMarkup:
    standart = InlineKeyboardButton(f'Обычное ({config.standart_price}₽)', callback_data='standart_movie')
    fake_soft = InlineKeyboardButton(f'С фейк софтом ({config.fake_soft_price}₽)', callback_data='fake_soft_movie')
    preview = InlineKeyboardButton(f'Превью ({config.preview_price}₽)', callback_data='preview')
    keyboard = InlineKeyboardMarkup().add(standart, fake_soft).add(preview)
    return keyboard


def profile() -> InlineKeyboardMarkup:
    add_balance = InlineKeyboardButton('Пополнить счёт', callback_data='add_balance')
    my_orders = InlineKeyboardButton('Мои заказы', callback_data='my_orders')
    promo = InlineKeyboardButton('Использовать промокод', callback_data='use_promo')
    keyboard = InlineKeyboardMarkup().add(add_balance, my_orders).add(promo)
    return keyboard


def admin_panel_service_on() -> InlineKeyboardMarkup:
    ban = InlineKeyboardButton('Заблокировать', callback_data='setban')
    unban = InlineKeyboardButton('Разблокировать', callback_data='unban')
    give_balance = InlineKeyboardButton('Выдать баланс', callback_data='give_balance')
    del_balance = InlineKeyboardButton('Забрать баланс', callback_data='remove_balance')
    add_promo = InlineKeyboardButton('Создать промокод', callback_data='create_promo')
    posting = InlineKeyboardButton('Рассылка', callback_data='posting')
    service = InlineKeyboardButton('🔴 Админ не в сети', callback_data='service_on')
    keyboard = InlineKeyboardMarkup(row_width=2).add(ban, unban).add(give_balance, del_balance).add(add_promo, posting).add(service)
    return keyboard


def admin_panel_service_off() -> InlineKeyboardMarkup:
    ban = InlineKeyboardButton('Заблокировать', callback_data='setban')
    unban = InlineKeyboardButton('Разблокировать', callback_data='unban')
    give_balance = InlineKeyboardButton('Выдать баланс', callback_data='give_balance')
    del_balance = InlineKeyboardButton('Забрать баланс', callback_data='remove_balance')
    add_promo = InlineKeyboardButton('Создать промокод', callback_data='create_promo')
    posting = InlineKeyboardButton('Рассылка', callback_data='posting')
    service = InlineKeyboardButton('🟢 Админ в сети', callback_data='service_off')
    keyboard = InlineKeyboardMarkup(row_width=2).add(ban, unban).add(give_balance, del_balance).add(add_promo, posting).add(service)
    return keyboard


def update_seo(user_id, url) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(row_width=2)

    keyboard.add(
        InlineKeyboardButton(f"🔄 Обновить информацию", callback_data=f"update_seo|{user_id}|{url}"),
    )

    return keyboard


def cancel_inline() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"🛑 Отмена", callback_data=f"cancel")
    )

    return keyboard


def payment_choice() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"💎 CrystalPay", callback_data=f"crystal_add")
    )

    return keyboard


def get_check_crystalpay_payment_markup(url, payment_id, payment_sum):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(
            text=f"💳 Оплатить",
            url=url
        )
    )
    keyboard.add(
        InlineKeyboardButton(
            text=f"🔄 Проверить оплату",
            callback_data=f"check_crystalpay|{payment_id}|{payment_sum}"
        )
    )
    return keyboard


def get_check_qiwi_payment_markup(url, payment_id, payment_sum):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(
            text=f"💳 Оплатить",
            url=url
        )
    )
    keyboard.add(
        InlineKeyboardButton(
            text=f"🔄 Проверить оплату",
            callback_data=f"check_qiwi|{payment_id}|{payment_sum}"
        )
    )
    return keyboard


def seo_request(user_id, order_id) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"🟡 Принять", callback_data=f"seo_request|{user_id}|{order_id}|ok"),
        InlineKeyboardButton(f"❌ Отказать", callback_data=f"seo_request|{user_id}|{order_id}|fail")
    )

    return keyboard


def movie_request(user_id, order_id, type) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"✅ Принять", callback_data=f"movie_request|{user_id}|{order_id}|{type}|ok"),
        InlineKeyboardButton(f"❌ Отказать", callback_data=f"movie_request|{user_id}|{order_id}|{type}|fail")
    )

    return keyboard


def seo_request_failed(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"❌ {username} отклонил эту заявку", callback_data=f"seo_request_failed")
    )

    return keyboard


def seo_request_finished(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"✅ {username} выполнил эту заявку", callback_data=f"seo_request_ok")
    )

    return keyboard


def seo_request_next_step(user_id, order_id) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(f"✅ Успешно", callback_data=f"seo_request_next_step|{user_id}|{order_id}|ok"),
        InlineKeyboardButton(f"❌ Неудачно", callback_data=f"seo_request_next_step|{user_id}|{order_id}|fail")
    )
    return keyboard


def movie_request_failed(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"❌ {username} отклонил эту заявку", callback_data=f"movie_request_failed")
    )

    return keyboard


def movie_request_finished(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"✅ {username} выполнил эту заявку", callback_data=f"movie_request_ok")
    )

    return keyboard


def movie_request_next_step(user_id, order_id, type) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(f"✅ Успешно", callback_data=f"movie_request_next_step|{user_id}|{order_id}|{type}|ok"),
        InlineKeyboardButton(f"❌ Неудачно", callback_data=f"movie_request_next_step|{user_id}|{order_id}|{type}|fail")
    )
    return keyboard


def link_request(user_id) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(f"✅ Принять", callback_data=f"link_request|{user_id}|ok"),
        InlineKeyboardButton(f"❌ Отказать", callback_data=f"link_request|{user_id}|fail")
    )

    return keyboard


def link_request_next_step(user_id) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(f"✅ Успешно", callback_data=f"link_request_next_step|{user_id}|ok"),
        InlineKeyboardButton(f"❌ Неудачно", callback_data=f"link_request_next_step|{user_id}|fail")
    )
    return keyboard


def link_request_failed(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"❌ {username} отклонил эту заявку", callback_data=f"link_request_failed")
    )

    return keyboard


def link_request_finished(username) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()

    keyboard.add(
        InlineKeyboardButton(f"✅ {username} выполнил эту заявку", callback_data=f"link_request_ok")
    )

    return keyboard