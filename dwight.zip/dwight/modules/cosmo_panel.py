import requests
import config
endpoint = 'https://cosmopanel.ru/api/v2'


def fetch_balance():
    try:
        api_key = config.cosmo_api_token
        data = {
            'key': api_key,
            'action': 'balance'
        }
        req = requests.post(endpoint, data=data).json()
        balance = req['balance']
        currency = req['currency']
        return f"<b>Баланс на COSMOPANEL: {balance} {currency}</b>"

    except:
        return f"<b>Что то не так с COSMOPANEL</b>"
def create_likes_order(count, link):
    api_key = config.cosmo_api_token
    data = {
        'key': api_key,
        'action': 'add',
        'service': 351,
        'link': link,
        'quantity': count
    }
    req = requests.post(endpoint, data=data).json()
    return req


def create_views_order(count, link):
    api_key = config.cosmo_api_token
    data = {
        'key': api_key,
        'action': 'add',
        'service': 845,
        'link': link,
        'quantity': count
    }
    req = requests.post(endpoint, data=data).json()
    return req


def create_comms_order(comms, link):
    api_key = config.cosmo_api_token
    data = {
        'key': api_key,
        'action': 'add',
        'service': 1412,
        'link': link,
        'comments': comms
    }
    req = requests.post(endpoint, data=data).json()
    return req