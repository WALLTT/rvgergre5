﻿# токен бота
bot_token = '6217263840:AAH2F1JRor4__UXj9hJTL90lrLnC1bQDovU'
cosmo_api_token = '8f797ae44f2cecdc1ed2480b9615bfa9'

# кристал настройки (в кассе можно взять)
crystalpay_login = 'RedSEO'
crystalpay_name = 'redseo'
crystalpay_secret_one = '0922a9f28469d2e4ecd092ad9e6a1815482549ae'
crystalpay_secret_two = 'e91ec5912275f2242ada93e222fc4b8381f371d5'

qiwi_p2p_token = 'eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6ImN2ank1aS0wMCIsInVzZXJfaWQiOiI3OTI4MDIyMDQyNCIsInNlY3JldCI6IjMwYmNjM2EzN2I0MmRkNTE2ZTI4OWNhNDcwZDQ5MjExMTlmY2ZhMWNlZThmY2JkNmRjOTU1ZmI3ZmY2YjY2MzIifX0='
qiwi_token = '6ace20104decf674e193771d8d2b2d1f'
qiwi_number = '+79365039650'
support_username = '@breathdevil' # юзернейм саппорта

seo_price = 150 # цена за сео
standart_price = 300 # цена за standart
fake_soft_price = 500 # цена за fake soft
preview_price = 47 # цена за preview
link_price = 1200 # цена за вязку

requests_chat_id = -1001954001554 # id канала с заявками
movie_chat_id = -1001954001554 # id канала с создание превью и мувиков
link_chat_id = -1001954001554 # id канала для вязки

admin = 5928888984# admin id
linker = 5928888984 # вяз ид
min_sum_payment = 50 # минимальная сумма пополнения

log_order_channel =  -1001962651899
log_channel =  -1001962651899
seo_queue =  -1001815525821
vds_count = 5 # количество дедиков
