import hashlib

import requests

class Crystalpay:

    def __init__(
        self, 
        crystalpay_login, 
        crystalpay_name, 
        crystalpay_secret_one, 
        crystalpay_secret_two
    ):
        self._crystalpay_login = crystalpay_login
        self._crystalpay_name = crystalpay_name
        self._crystalpay_secret_one = crystalpay_secret_one
        self._crystalpay_secret_two = crystalpay_secret_two

    def get_balance(self):
        response = requests.post(
            'https://api.crystalpay.io/v2/balance/info/',
            json={
                'auth_login': self._crystalpay_login,
                'auth_secret': self._crystalpay_secret_one,
            },
        )
        return response.json()
    
    def get_payment(self, amount):
        response = requests.post(
            'https://api.crystalpay.io/v2/invoice/create/',
            json={
                'auth_login': self._crystalpay_login,
                'auth_secret': self._crystalpay_secret_one,
                'amount': amount,
                'lifetime': 240,
                'type': 'purchase'
            },
        )
        return response.json()

    def payment_check(self, payment_id):
        response = requests.post(
            'https://api.crystalpay.io/v2/invoice/info/',
            json={
                'auth_login': self._crystalpay_login,
                'auth_secret': self._crystalpay_secret_one,
                'id': payment_id
            },
        )
        return response.json()

    def withdraw(self, amount, wallet, currency):
        sign = f"{amount}:{currency}:{wallet}:{self._crystalpay_secret_two}"
        sign = hashlib.sha1(sign.encode())
        response = requests.post(
            'https://api.crystalpay.io/v2/payoff/create/',
            json={
                'auth_login': self._crystalpay_login,
                'auth_secret': self._crystalpay_secret_one,
                'signature': sign,
                'amount': amount,
                'wallet': wallet,
                'method': currency,
                'subtract_from': 'amount'
            },
        )
        return response.json()

