import random
import sqlite3
import threading
import time

import requests
from aiogram import Dispatcher, Bot, executor, types
import asyncio
import config
import warnings
import keyboard
import database
from aiogram.dispatcher import FSMContext
from states import *
from modules import seo_checker, cosmo_panel
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from crystalpay import Crystalpay
from pyqiwip2p import QiwiP2P
import python_qiwi
from datetime import datetime
import pytz
import schedule

wallet = python_qiwi.QiwiWаllet(config.qiwi_number, config.qiwi_token)
storage = MemoryStorage()
db = database.Database()
bot = Bot(token=config.bot_token, parse_mode="HTML")
dp = Dispatcher(bot, loop=asyncio.get_event_loop(), storage=storage)
warnings.filterwarnings("ignore", category=DeprecationWarning)

crystalpay = Crystalpay(
    crystalpay_login=config.crystalpay_login,
    crystalpay_name=config.crystalpay_name,
    crystalpay_secret_one=config.crystalpay_secret_one,
    crystalpay_secret_two=config.crystalpay_secret_two
)

p2p = QiwiP2P(auth_key=config.qiwi_p2p_token)


async def try_message(id: int, text: str):
    try:
        await bot.send_message(chat_id=id, text=text)
    except:
        pass


def get_now():
    return datetime.now(pytz.timezone('Europe/Moscow'))


class User:
    def __init__(self, user_id: int, username: str):
        self.user_id = user_id
        self.username = "@" + str(username)

    async def fetch(self):
        user = await db.fetch("SELECT * FROM `users` WHERE `id`=?", self.user_id)
        return user

    async def fetch_all(self):
        users = await db.fetch_all("SELECT * FROM `users`")
        return users

    async def create(self):
        await db.execute("INSERT INTO `users` (id, username) VALUES (?, ?)", self.user_id, self.username)

    async def add_balance(self, sum, user_id):
        await db.execute(f"UPDATE users SET balance=balance+{sum} WHERE `id`=? OR `username`=?", user_id, user_id)

    async def deposit(self, sum, user_id):
        await db.execute(f"UPDATE users SET balance=balance+{sum}, all_received=all_received+{sum} WHERE id=?", user_id)

    async def del_balance(self, sum, user_id):
        await db.execute(f"UPDATE users SET balance=balance-{sum} WHERE `id`=? OR `username`=?", user_id, user_id)

    async def create_order(self, username, url):
        await db.execute("INSERT INTO `orders` (username, url) VALUES (?, ?)", username, url)

    async def create_movie_order(self, username, data, type):
        await db.execute("INSERT INTO `movies` (username, data, type) VALUES (?, ?, ?)", username, data, type)

    async def fetch_order(self, id):
        order = await db.fetch("SELECT * FROM `orders` WHERE `id`=?", id)
        return order

    async def fetch_movie_order(self, id):
        order = await db.fetch("SELECT * FROM `movies` WHERE `id`=?", id)
        return order

    async def fetch_order_by_url(self, url):
        order = await db.fetch_all("SELECT * FROM `orders` WHERE `url`=?", url)
        return order[-1]

    async def fetch_movie_order_by_url(self, url):
        order = await db.fetch_all("SELECT * FROM `movies` WHERE `data`=?", url)
        return order[-1]

    async def fetch_orders(self, username):
        orders = await db.fetch_all("SELECT * FROM `orders` WHERE `username`=?", username)
        return orders

    async def fetch_movie_orders(self, username):
        orders = await db.fetch_all("SELECT * FROM `movies` WHERE `username`=?", username)
        return orders

    async def fetch_all_orders(self):
        orders = await db.fetch_all("SELECT status FROM `orders`")
        return orders

    async def fetch_all_movie_orders(self):
        orders = await db.fetch_all("SELECT status FROM `movies`")
        return orders

    async def update_order(self, order_id, status):
        await db.execute(f"UPDATE orders SET status=? WHERE id=?", status, order_id)

    async def update_movie_order(self, order_id, status):
        await db.execute(f"UPDATE movies SET status=? WHERE id=?", status, order_id)

    async def set_admin(self, user_id):
        await db.execute(f"UPDATE users SET admin=? WHERE id=?", 1, user_id)

    async def ban(self, user: str):
        await db.execute("UPDATE `users` SET `ban`=1 WHERE `id`=? OR `username`=?", user, user)

    async def unban(self, user: str):
        await db.execute("UPDATE `users` SET `ban`=0 WHERE `id`=? OR `username`=?", user, user)

    async def order_sum(self, user: str):
        await db.execute("UPDATE `users` SET `orders_count`=orders_count+1 WHERE `id`=? OR `username`=?", user, user)

    async def create_promo(self, promo, activates_expired, sum):
        await db.execute("INSERT INTO `promo` (used, promo, activates_expired, sum) VALUES (?, ?, ?, ?)", "", promo,
                         activates_expired, sum)

    async def fetch_promo(self, promo):
        promo = await db.fetch("SELECT * FROM `promo` WHERE `promo`=?", promo)
        return promo

    async def use_promo(self, promo, username):
        await db.execute("UPDATE promo SET used=used || ? WHERE promo=?", username + " ", promo)
        await db.execute("UPDATE promo SET activates_expired=activates_expired-1 WHERE promo=?", promo)

    async def parse_status(self):
        status = await db.fetch("SELECT status FROM `admin_status` WHERE uid=1")
        return status['status']

    async def set_status(self, status):
        await db.execute("UPDATE admin_status SET status=? WHERE uid=1", status)

    async def parse_lstatus(self):
        status = await db.fetch("SELECT status FROM `linker_status` WHERE uid=1")
        return status['status']

    async def set_lstatus(self, status):
        await db.execute("UPDATE linker_status SET status=? WHERE uid=1", status)

    async def CreateTask(self, order_id: str, status: str, time_confirm):
        await db.execute(
            "INSERT INTO `Task` (`id`, `username`, `order_id`, `status`, `time_confirm`, `creating_date`) VALUES (? ,?, ?, ?, ?, ?)",
            self.user_id, self.username, order_id, status, time_confirm, str(get_now()))


class WorkerInformation():
    def __init__(self, id: int, username: str, balance: int, completed: int, uncompleted: int):
        self.id = id
        self.username = username
        self.balance = balance
        self.completed = completed
        self.uncompleted = uncompleted


class Connection():
    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)

    def __enter__(self):
        return self.connection

    def __exit__(self, *args):
        self.connection.close()


class Worker():

    def __init__(self, id: int, username: str, db_name: str):
        self.id = id
        self.username = username
        self.db_name = db_name

    def GetData(self) -> WorkerInformation:
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            response = cursor.execute(
                "SELECT `id`, `username`, `balance`, `completed`, `uncompleted` FROM `Worker` where id = ?",
                [self.id]).fetchone()
            return WorkerInformation(response[0], response[1], response[2], response[3], response[4])

    def Add(self) -> bool:
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            if cursor.execute("SELECT `id` FROM `Worker` where `id` = ?", [self.id]).fetchone():
                return False
            else:
                cursor.execute("INSERT INTO `Worker` (`id`, `username`) VALUES (?, ?)",
                               [self.id, self.username])
                connection.commit()
                return True

    def Remove(self):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()

            cursor.execute("DELETE FROM `Worker` where id = ?",
                           [self.id])
            connection.commit()
            return True

    def AddBalance(self, value: int):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            cursor.execute("UPDATE `Worker` SET `balance` = balance + ? where id = ?", [value, self.id])
            connection.commit()

    def Completed(self):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            cursor.execute("UPDATE `Worker` SET `completed` = completed + 1 where id = ?", [self.id])
            connection.commit()

    def UnCompleted(self):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            cursor.execute("UPDATE `Worker` SET `uncompleted` = uncompleted + 1 where id = ?", [self.id])
            connection.commit()

    def GetOrderToDay(self, status: str, time_confirm: str):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            task = cursor.execute("SELECT * FROM `Task` where (`id`, `status`, `time_confirm`) = (?, ?, ?)",
                                  [self.id, status, time_confirm]).fetchall()
            return [1 for i in task if i[5].split(" ")[0] in str(get_now())]

    def CreateTask(self, order_id: int, status: str):
        with Connection(self.db_name) as connection:
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO `Task` (`id`, `username`, `order_id`, `status`, `creating_date`) VALUES (?, ?, ?, ?, ?)",
                [self.id, self.username, order_id, status, get_now()])

            connection.commit()


def isWorker(id: int, db_name: str):
    with Connection(db_name) as connection:
        cursor = connection.cursor()
        if cursor.execute("SELECT `id` FROM `Worker` where `id` = ?", [id]).fetchone():
            return True
        return False


def GetAllWorker(db_name: str) -> list[WorkerInformation]:
    with Connection(db_name) as connection:
        cursor = connection.cursor()
        response = cursor.execute(
            "SELECT `id`, `username`, `balance`, `completed`, `uncompleted` FROM `Worker`").fetchall()
        return [WorkerInformation(i[0], i[1], i[2], i[3], i[4]) for i in response]


async def set_admin(user_id):
    await db.execute(f"UPDATE users SET admin=? WHERE id=?", 1, user_id)


#asyncio.run(db.CreateTable('''CREATE TABLE Task (
#                                id INT NOT NULL,
#                                username TEXT,
#                                order_id INT,
#                                status TEXT,
#                                time_confirm TEXT,
#                                creating_date date);'''))

#asyncio.run(db.CreateTable('''CREATE TABLE Worker (
#                                 id INT NOT NULL,
#                                 username TEXT,
#                                 balance INT default 0,
#                                 completed INT default 0,
#                                 uncompleted INT default 0);'''))

@dp.message_handler(commands=["add_worker"])
async def add_worker_command(message: types.Message):
    user = await User(message.from_user.id, message.from_user.username).fetch()
    admin_status = user['admin']
    if admin_status == 1:
        # await try_message(id=local_chanel['log_channel'], text=f"#WhiteRabbit Пользователь {message.from_user.username}({message.from_user.id}) использовал команду {message.text.replace('/', '#')}")
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO Пользователь {message.from_user.username}({message.from_user.id}) использовал команду {message.text.replace('/', '#')}")
        try:
            data = await bot.get_chat(int(message.text.split(" ")[1]))
            worker = Worker(int(message.text.split(" ")[1]), data.username, "database.db")
            if not worker.Add():
                await message.answer("Данный человек уже явялется воркером")
                return
            await message.answer("Успешно")
        except Exception as ex:
            print(ex)
            await message.answer("Что то пошло не так")


@dp.message_handler(commands=["remove_worker"])
async def remove_worker_command(message: types.Message):
    user = await User(message.from_user.id, message.from_user.username).fetch()
    admin_status = user['admin']
    if admin_status == 1:
        # await try_message(id=local_chanel['log_channel'], text=f"#WhiteRabbit Пользователь {message.from_user.username}({message.from_user.id}) использовал команду {message.text.replace('/', '#')}")
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO Пользователь {message.from_user.username}({message.from_user.id}) использовал команду {message.text.replace('/', '#')}")
        data = await bot.get_chat(int(message.text.split(" ")[1]))
        worker = Worker(int(message.text.split(" ")[1]), data.username, "database.db")
        worker.Remove()
        await message.answer("Успешно")


@dp.message_handler(commands=['on'])
async def on_handler(msg: types.Message):
    if msg.from_user.id == config.linker:
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO Пользователь {msg.from_user.username}({msg.from_user.id}) использовал команду {msg.text.replace('/', '#')}")
        await User(msg.from_user.id, msg.from_user.username).set_lstatus(1)
        await msg.answer("<b>Вы успешно установили статус на ONLINE</b>")
    else:
        await msg.answer("<b>Эта команда доступна только вязчику</b>")


@dp.message_handler(commands=['off'])
async def off_handler(msg: types.Message):
    if msg.from_user.id == config.linker:
        await User(msg.from_user.id, msg.from_user.username).set_lstatus(0)
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO Пользователь {msg.from_user.username}({msg.from_user.id}) использовал команду {msg.text.replace('/', '#')}")
        await msg.answer("<b>Вы успешно установили статус на OFFLINE</b>")
    else:
        await msg.answer("<b>Эта команда доступна только вязчику</b>")


@dp.message_handler(commands=['stats'])
async def stats_handler(msg: types.Message):
    user_id, username = msg.from_user.id, msg.from_user.username
    user = await User(user_id, username).fetch()
    users = await User(user_id, username).fetch_all()
    balance_users = 0
    received = 0
    orders_count = 0
    users_count = 0
    for us in users:
        balance_users += us['balance']
        received += us['all_received']
        orders_count += us['orders_count']
        users_count += 1

    if user['admin'] == 1:
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO Пользователь {msg.from_user.username}({msg.from_user.id}) использовал команду {msg.text.replace('/', '#')}")
        msgg = f"""
<b>⚙️ Общая статистика:</b>

<b>👹 Баланс всех пользователей: {round(balance_users, 1)} рублей</b>
<b>💸 Всего пополнено на: {received} рублей</b>
<b>🚀 SEO-заказов: {orders_count} шт.</b>
<b>🎎 Всего пользователей: {users_count} чел.</b> 

<b>🥝 QIWI баланс: {wallet.balance()} рублей</b>

{cosmo_panel.fetch_balance()}"""
        await msg.answer(msgg)
    else:
        await msg.answer("<b>Эта команда доступна только администраторам</b>")


@dp.message_handler(commands=['start'])
async def start_handler(msg: types.Message):
    try:
        user_id, username = msg.from_user.id, msg.from_user.username
        user = await User(user_id, username).fetch()
        if msg.from_user.username == "None":
            return
        if not user:
            await User(user_id, username).create()
            return await msg.answer("""
<b>Добро пожаловать в Raven SEO!
🚀 CЕО О КОТОРОМ ТЫ МЕЧТАЛ 🚀

Канал с информацией: @RavenSEO_INFO</b>""", reply_markup=keyboard.start_keyboard())
        else:
            if user['ban'] == 1:
                return await msg.answer("<b>Вы заблокированы администратором проекта!</b>")
            else:
                await msg.answer("""
<b>Добро пожаловать в Raven SEO!
CЕО О КОТОРОМ ТЫ МЕЧТАЛ 👍

Канал с информацией: @RavenSEO_INFO</b>""", reply_markup=keyboard.start_keyboard())
    except Exception as ex:
        await msg.answer(f"Произошла ошибка! {ex}")


@dp.message_handler(commands=['admin'])
async def admin_handler(msg: types.Message):
    user = await User(msg.from_user.id, msg.from_user.username).fetch()
    admin_status = user['admin']
    if admin_status == 1:
        await try_message(id=config.log_channel,
                          text=f"#RavenSEO_INFO Пользователь {msg.from_user.username}({msg.from_user.id}) использовал команду {msg.text.replace('/', '#')}")
        status = await User(msg.from_user.id, msg.from_user.username).parse_status()
        if status == 1:
            await msg.answer("<b>Админ-панель:</b>", reply_markup=keyboard.admin_panel_service_on())
        else:
            await msg.answer("<b>Админ-панель:</b>", reply_markup=keyboard.admin_panel_service_off())
    else:
        await msg.answer("<b>Эта команда доступна только администраторам.</b>")


@dp.message_handler(content_types=['text'])
async def text_handler(msg: types.Message):
    try:
        user_id, username = msg.from_user.id, msg.from_user.username
        user = await User(user_id, username).fetch()
        if time.time() - user['req_check_time'] > 600:
            await db.execute(f"UPDATE users SET req_check=0 WHERE id={msg.from_user.id}")
        if user['ban'] == 1:
            return await msg.answer("<b>Вы заблокированы администратором проекта!</b>")
        text = msg.text
        if text == "🧨 Профиль":
            balance = user['balance']
            all_received = user['all_received']
            orders_count = user['orders_count']
            await msg.answer(f"""
📱 Ваш профиль:
➖➖➖➖➖➖➖➖➖➖➖➖➖
💯 Мой ID: <code>{user['id']}</code>
🛂 Логин: @{msg.from_user.username}
➖➖➖➖➖➖➖➖➖➖➖➖➖
💎 Баланс: {balance} рублей
💸 Всего пополнено: {all_received} рублей
💈 Всего заказов: {orders_count} шт.
""", reply_markup=keyboard.profile())

        elif text == "🔙 Вернуться в главное меню":
            await msg.answer("<b>Главное меню:</b>", reply_markup=keyboard.start_keyboard())

        elif text == "🩸 Правила":
            await msg.answer(f"""
    <b>https://teletype.in/@ravenseo/iFlN5cXd7S0</b>
""")

        elif text == '❤️ Cаппорт':
            await msg.answer(f"<b>Актуальный контакт саппорта - <i>{config.support_username}</i></b>")

        elif text == '🚀 Накрутка SEO':
            await SeoRequest.get_url.set()
            await msg.answer(
                f"<b>SEO Boost\nСтоимость услуги - {config.seo_price} рублей.\n\nОтправьте ссылку на видео:</b>",
                reply_markup=keyboard.cancel_inline())

        elif text == '🎈 Информация':
            user = User(msg.from_user.id, msg.from_user.username)
            orders = await user.fetch_all_orders()
            orders_list = []
            for x in orders:
                if x['status'] == 0 or x['status'] == 1:
                    orders_list.append(x['status'])
            if len(orders_list) != 0:
                await msg.answer(
                    f"<b>🪩 Занято слотов: {len(orders_list)}\n⚙️ Свободных мест: {config.vds_count - len(orders_list)}\n👉🏽 Ждем именно твоей заявки\n\n\n🎈 Информационный канал: @RavenSEO_INFO\n🚀 Тех. поддержка: @breathdevil\n❤️‍🔥 Тема с отзывами: https://zelenka.guru/threads//</b>")
            elif len(orders_list) == config.vds_count:
                await msg.answer(f"<b>🎈 Занято слотов: {len(orders_list)}\n⚙️ Свободных мест: {config.vds_count - len(orders_list)} \n🎈 Информационный канал: @RavenSEO_INFO\n🚀 Тех. поддержка: @breathdevil\n❤️‍🔥 Тема с отзывами: https://zelenka.guru/threads//</b>")
            else:
                await msg.answer(f"<b>🎈 Занято слотов: {len(orders_list)}\n⚙️ Свободных мест: {config.vds_count - len(orders_list)} \n🎈 Информационный канал: @RavenSEO_INFO\n🚀 Тех. поддержка: @breathdevil\n❤️‍🔥 Тема с отзывами: https://zelenka.guru/threads//</b>")
    except Exception as ex:
        await msg.answer(f"Произошла ошибка! {ex}")


async def get_seo(url, msg: types.Message):
    if 'htt' and 'youtu' in url:
        data = seo_checker.get_seo(url)
        message = data[0]
        short_url = f"https://youtu.be/{data[1]}"
        await msg.answer(message, disable_web_page_preview=True,
                         reply_markup=keyboard.update_seo(msg.from_user.id, short_url))


@dp.message_handler(state=SeoRequest.get_url, content_types=['text'])
async def seo_request(msg: types.Message, state: FSMContext):
    try:
        url = msg.text
        if 'youtu' in url:
            user = User(msg.from_user.id, msg.from_user.username)
            status = await user.parse_status()
            if status == 1:
                user_ban = await user.fetch()
                if user_ban['ban'] == 1:
                    return await msg.answer("<b>Вы заблокированы администратором проекта!</b>")
                if user_ban['balance'] < config.seo_price:
                    await state.finish()
                    return await msg.answer(
                        f"<b>Недостаточно средств на балансе. Цена данной услуги - {config.seo_price} рублей!</b>")
                orders = await user.fetch_all_orders()
                orders_list = []
                for x in orders:
                    if x['status'] == 0 or x['status'] == 1:
                        orders_list.append(x['status'])
                if len(orders_list) == config.vds_count:
                    await msg.answer(
                        f"<b>В данный момент невозможно отправить заявку, так как очередь занята.</b>")
                    await state.finish()
                    return
                await user.create_order(f"@{msg.from_user.username}", url)
                orders = await user.fetch_all_orders()
                orders_list = []
                for x in orders:
                    if x['status'] == 0 or x['status'] == 1:
                        orders_list.append(x['status'])
                await user.order_sum(msg.from_user.id)
                order = await user.fetch_order_by_url(url)
                await msg.answer(
                    f"<b>Вы отправили заявку на накрутку SEO. С вашего баланса будет списано {config.seo_price} рублей.</b>")
                await bot.send_message(config.seo_queue,
                                       f"<b>[⚙] Поступила заявка на SEO, в очереди {len(orders_list)} человек(а).\n{'Осталось мест: ' + str(config.vds_count - len(orders_list)) + ' шт.' if len(orders_list) < config.vds_count else 'Свободных мест не осталось.'}</b>")
                order_id = order['id']
                await bot.send_message(config.requests_chat_id,
                                       f"""
<i>Заявка №{order_id}</i>
<b>📢 Новая заявка на накрутку SEO от @{msg.from_user.username}!

🔗 Ссылка на видео: {url}</b>
""", reply_markup=keyboard.seo_request(msg.from_user.id, order_id))
                await user.del_balance(config.seo_price, msg.from_user.id)
                await state.finish()
            else:
                await state.finish()
                return await msg.answer("<b>Администратор сейчас не в сети. Нельзя подать заявку!</b>")
        else:
            await state.finish()
            return await msg.answer("<b>Некорректная ссылка.</b>")

    except Exception as ex:
        print(ex)
        await msg.answer(f"Произошла ошибка!")


@dp.callback_query_handler(regexp=r"seo_request\|(.+)\|(.+)\|(.+)", state='*')
async def update_seo_callback(callback: types.CallbackQuery):
    if isWorker(callback.from_user.id, "database.db"):
        data = callback.data.split("|")
        user_id = data[1]
        order_id = data[2]
        status = data[3]
        user = User(callback.from_user.id, callback.from_user.username)
        order = await user.fetch_order(order_id)
        url = order['url']
        if status == 'ok':
            await user.update_order(order_id, 1)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на накрутку SEO одобрена!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Одобрено ✅
    🔗 Ссылка на ролик: {url}
    </b>
    """, disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.requests_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.seo_request_next_step(user_id, order_id))
        elif status == 'fail':
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) не смог выполнить заказ #{order_id}")
            await user.update_order(order_id, 2)
            orders = await user.fetch_all_orders()
            orders_list = []
            for x in orders:
                if x['status'] == 0 or x['status'] == 1:
                    orders_list.append(x['status'])
            if orders_list:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас в очереди: {len(orders_list)} человек(а), скорее закидывай на SEO!\nОсталось мест: {config.vds_count - len(orders_list)} шт.</b>")
            else:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас очередь пуста, скорее закидывай на SEO!</b>")
            await user.add_balance(config.seo_price, user_id)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на накрутку SEO отклонена!
    💳Деньги возвращены на ваш баланс!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Отклонено ❌
    🔗 Ссылка на ролик: {url}
    </b>""", disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.requests_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.seo_request_failed(
                                                    f"@{callback.from_user.username}"))
            moscow_time = str(datetime.now(pytz.timezone('Europe/Moscow')))
            hours = moscow_time.split(" ")[-1].split(":")[0]
            if 0 < int(hours) < 9:
                await user.CreateTask(order_id, "uncompleted", "night")
            else:
                await user.CreateTask(order_id, "uncompleted", "day")
    else:
        await callback.answer("У вас недостаточно прав")


@dp.callback_query_handler(regexp=r"movie_request\|(.+)\|(.+)\|(.+)\|(.+)", state='*')
async def update_movie_callback(callback: types.CallbackQuery):
    if isWorker(callback.from_user.id, "database.db"):
        data = callback.data.split("|")
        user_id = data[1]
        order_id = data[2]
        type = data[3]
        status = data[4]
        user = User(callback.from_user.id, callback.from_user.username)
        order = await user.fetch_movie_order(order_id)
        task = order['data']
        if status == 'ok':
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) принял заказ #{order_id}")
            await user.update_movie_order(order_id, 1)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на создание видео/превью одобрена!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Одобрено ✅
    💬 Информация о задании: <i>{task}</i>
    </b>
    """, disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.movie_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.movie_request_next_step(user_id, order_id, type))
        elif status == 'fail':
            await user.update_movie_order(order_id, 2)
            if int(type) == 1:
                await user.add_balance(config.standart_price, user_id)
            elif int(type) == 2:
                await user.add_balance(config.fake_soft_price, user_id)
            elif int(type) == 3:
                await user.add_balance(config.preview_price, user_id)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на создание видео/превью отклонена!
    💳Деньги возвращены на ваш баланс!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Отклонено ❌
    💬 Информация о задании: <i>{task}</i>
    </b>""", disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.movie_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.movie_request_failed(
                                                    f"@{callback.from_user.username}"))
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) отменил заказ #{order_id}")
    else:
        await callback.answer("У вас недостаочно прав")


@dp.callback_query_handler(regexp=r"seo_request_next_step\|(.+)\|(.+)\|(.+)", state='*')
async def update_seo_callback_next_step(callback: types.CallbackQuery):
    if isWorker(callback.from_user.id, "database.db"):
        data = callback.data.split("|")
        user_id = data[1]
        order_id = data[2]
        status = data[3]
        user = User(callback.from_user.id, callback.from_user.username)
        order = await user.fetch_order(order_id)
        url = order['url']
        if status == 'ok':
            await user.update_order(order_id, 3)
            orders = await user.fetch_all_orders()
            orders_list = []
            for x in orders:
                if x['status'] == 0 or x['status'] == 1:
                    orders_list.append(x['status'])
            if orders_list:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас в очереди: {len(orders_list)} человек(а), скорее закидывай на SEO!\nОсталось мест: {config.vds_count - len(orders_list)} шт.</b>")
            else:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас очередь пуста, скорее закидывай на SEO!</b>")
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на накрутку SEO завершена!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Выполнено ✅
    🔗 Ссылка на ролик: {url}

    😊 Оставь пожалуйста отзыв: https://zelenka.guru/threads//
    </b>
        """, disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.requests_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.seo_request_finished(
                                                    f"@{callback.from_user.username}"))
            moscow_time = str(datetime.now(pytz.timezone('Europe/Moscow')))
            hours = moscow_time.split(" ")[-1].split(":")[0]
            if 0 < int(hours) < 9:
                await user.add_balance(90, callback.from_user.id)
                await bot.send_message(callback.from_user.id, "<b>На ваш баланс зачислено 90 рублей!</b>")
                await user.CreateTask(order_id, "completed", "night")
            else:
                await bot.send_message(callback.from_user.id, "<b>На ваш баланс зачислено 70 рублей!</b>")
                await user.add_balance(70, callback.from_user.id)
                await user.CreateTask(order_id, "completed", "day")

        elif status == 'fail':
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) не смог выполнить заказ #{order_id}")
            await user.update_order(order_id, 2)
            orders = await user.fetch_all_orders()
            orders_list = []
            for x in orders:
                if x['status'] == 0 or x['status'] == 1:
                    orders_list.append(x['status'])
            if orders_list:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас в очереди: {len(orders_list)} человек(а), скорее закидывай на SEO!\nОсталось мест: {config.vds_count - len(orders_list)} шт.</b>")
            else:
                await bot.send_message(config.seo_queue,
                                       f"<b>[😋] Сейчас очередь пуста, скорее закидывай на SEO!</b>")
            await user.add_balance(config.seo_price, user_id)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на накрутку SEO отклонена!
    💳Деньги возвращены на ваш баланс!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Отклонено ❌
    🔗 Ссылка на ролик: {url}
        </b>""", disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.requests_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.seo_request_failed(
                                                    f"@{callback.from_user.username}"))

            moscow_time = str(datetime.now(pytz.timezone('Europe/Moscow')))
            hours = moscow_time.split(" ")[-1].split(":")[0]
            if 0 < int(hours) < 9:
                await user.CreateTask(order_id, "uncompleted", "night")
            else:
                await user.CreateTask(order_id, "uncompleted", "day")
    else:
        await callback.answer("У вас недостаточно прав")


@dp.callback_query_handler(regexp=r"movie_request_next_step\|(.+)\|(.+)\|(.+)\|(.+)", state='*')
async def update_movie_callback_next_step(callback: types.CallbackQuery):
    if isWorker(callback.from_user.id, "database.db"):
        data = callback.data.split("|")
        user_id = data[1]
        order_id = data[2]
        type = data[3]
        status = data[4]
        user = User(callback.from_user.id, callback.from_user.username)
        order = await user.fetch_movie_order(order_id)
        task = order['data']
        if status == 'ok':
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) завершил #{order_id}")
            await user.update_movie_order(order_id, 3)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на cоздание видео/превью выполнена!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Выполнено ✅
    💬 Информация о задании: <i>{task}</i>

    😊 Отставь пожалуйста отзыв: https://zelenka.guru/threads//
    </b>
        """, disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.movie_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.movie_request_finished(
                                                    f"@{callback.from_user.username}"))
        elif status == 'fail':
            await try_message(id=config.log_order_channel,
                              text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) не смог выполнить заказ #{order_id}")
            await user.update_order(order_id, 2)
            if int(type) == 1:
                await user.add_balance(config.standart_price, user_id)
            elif int(type) == 2:
                await user.add_balance(config.fake_soft_price, user_id)
            elif int(type) == 3:
                await user.add_balance(config.preview_price, user_id)
            await bot.send_message(user_id, f"""
    <b>Ваша заявка на создание видео/превью отклонена!
    💳Деньги возвращены на ваш баланс!

    📋 Информация о заявке: 

    Заявка №{order_id}
    ⚙️ Статус: Отклонено ❌
    💬 Информация о задании: <i>{task}</i>
    </b>""", disable_web_page_preview=True)
            await bot.edit_message_reply_markup(config.movie_chat_id, callback.message.message_id,
                                                reply_markup=keyboard.movie_request_failed(
                                                    f"@{callback.from_user.username}"))
            moscow_time = str(datetime.now(pytz.timezone('Europe/Moscow')))
            hours = moscow_time.split(" ")[-1].split(":")[0]
            if 0 < int(hours) < 9:
                await user.CreateTask(order_id, "uncompleted", "night")
            else:
                await user.CreateTask(order_id, "uncompleted", "day")
    else:
        await callback.answer("У вас недостаточно прав")


@dp.callback_query_handler(state="*", text="cancel")
async def cancel_handler(callback: types.CallbackQuery, state: FSMContext):
    if state:
        try:
            await callback.message.edit_text("<b>Действие отменено.</b>")
        except Exception as e:
            print(f"[-] Exception: {e}")
            await callback.answer("Действие отменено.")
        await state.finish()


@dp.callback_query_handler(regexp=r"add_balance", state='*')
async def add_balance(callback: types.CallbackQuery):
    await callback.message.answer("<b>Выберите платёжный метод:</b>", reply_markup=keyboard.payment_choice())


@dp.callback_query_handler(regexp=r"my_orders", state='*')
async def my_orders(callback: types.CallbackQuery):
    user_id, username = callback.from_user.id, callback.from_user.username
    user = User(user_id, username)
    ban = await user.fetch()
    if ban['ban'] == 1:
        return await callback.message.answer("<b>Вы заблокированы администратором проекта!</b>")
    orders = await user.fetch_orders("@" + username)
    count = 0
    msg = ""
    if orders:
        msg += "📋 Ваши последние 10 заявок:\n\n"
        for x in reversed(orders):
            if count != 10:
                count += 1
                msg += f"{count}. Заявка №<i>{x['id']}</i> | "
                if x['status'] == 0:
                    msg += "На рассмотрении ⏱\n"
                elif x['status'] == 1:
                    msg += "Одобрена ✅\n"
                elif x['status'] == 2:
                    msg += "Отклонена ❌\n"
                elif x['status'] == 3:
                    msg += "Завершена ✅\n"
                msg += f"    └ URL: {x['url']}\n"
    else:
        msg += "<b>❌ У вас нет ни одного завершенного заказа.</b>"
    await callback.message.answer(msg, disable_web_page_preview=True)


@dp.callback_query_handler(regexp=r"crystal_add", state='*')
async def add_balance_crystal_callback(callback: types.CallbackQuery):
    user = await User(callback.from_user.id, callback.from_user.username).fetch()
    if user['ban'] == 1:
        return await callback.message.answer("<b>Вы заблокированы администратором проекта!</b>")
    await CrystalMethod.get_sum.set()
    await callback.message.answer("<b>💎 Введите сумму платежа (в рублях):</b>", reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=CrystalMethod.get_sum, content_types=['text'])
async def add_balance_crystal_get_sum(msg: types.Message, state: FSMContext):
    user = await User(msg.from_user.id, msg.from_user.username).fetch()
    if user['ban'] == 1:
        return await msg.answer("<b>Вы заблокированы администратором проекта!</b>")
    payment_sum = msg.text
    if int(payment_sum) < config.min_sum_payment:
        await state.finish()
        return await msg.answer(f"<b>Указанная сумма меньше минимальной суммы ({config.min_sum_payment} рублей).</b>")
    payment_data = crystalpay.get_payment(payment_sum)
    print(payment_data)
    payment_url = payment_data['url']
    payment_id = payment_data['id']
    markup = keyboard.get_check_crystalpay_payment_markup(payment_url, payment_id, payment_sum)
    await bot.send_message(
        msg.from_user.id,
        f"<b>Информация о платеже:\n\nПлатежная система: 💎 CrystalPay\nСумма платежа: {payment_sum} рублей</b>",
        reply_markup=markup
    )
    await state.finish()


@dp.callback_query_handler(text_contains="check_crystalpay")
async def check_crystalpay(call: types.CallbackQuery):
    try:
        payment_id = call.data.split('|')[1]
        payment_sum = int(call.data.split('|')[2])
        payment_data = crystalpay.payment_check(payment_id)
        print(payment_data)
        if payment_data['state'] != 'payed':
            await bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text="<b>Оплата не найдена. ❌</b>",
                reply_markup=call.message.reply_markup
            )
            return

        if payment_sum >= 1000:
            await bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=f"<b>Ваш платёж был найден! ✅\n\nПлатежная система: 💎 CrystalPay\nСумма платежа: {payment_sum} рублей</b>"
            )
            await call.message.answer(f"<b>🎁 На баланс будет зачислен бонус ({payment_sum * 0.1}) рублей. Спасибо что выбрали Нас!</b>")
            await try_message(id=config.log_channel,
                              text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) пополнил баланс [💎 CrystalPay] на сумму: {payment_sum}, id: #{payment_id}")
            payment_sum = payment_sum + payment_sum * 0.1
            await User(call.from_user.id, call.from_user.username).deposit(payment_sum, call.from_user.id)
        else:
            await User(call.from_user.id, call.from_user.username).deposit(payment_sum, call.from_user.id)
            await bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=f"<b>Ваш платёж был найден! ✅\n\nПлатежная система: 💎 CrystalPay\nСумма платежа: {payment_sum} рублей</b>"

            )
            await try_message(id=config.log_channel,
                              text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) пополнил баланс[CrystalPay] на сумму: {payment_sum}, id: #{payment_id}")
    except:
        pass


@dp.callback_query_handler(text_contains="setban")
async def ban(call: types.CallbackQuery):
    await AdminActions.ban_get_data.set()
    await call.message.answer("<b>Введите username/id нужного вам человека.</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) использовал команду #{call.data}")


@dp.message_handler(state=AdminActions.ban_get_data, content_types=['text'])
async def ban_handler(msg: types.Message, state: FSMContext):
    ban_user = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    await user.ban(ban_user)
    await msg.answer("<b>Если такой пользователь есть - он был забанен.</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="unban")
async def unban(call: types.CallbackQuery):
    await AdminActions.unban_get_data.set()
    await call.message.answer("<b>Введите username/id нужного вам человека.</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) использовал команду #{call.data}")


@dp.message_handler(state=AdminActions.unban_get_data, content_types=['text'])
async def unban_handler(msg: types.Message, state: FSMContext):
    unban_user = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    await user.unban(unban_user)
    await msg.answer("<b>Если такой пользователь есть - он был разбанен.</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="give_balance")
async def give_balance(call: types.CallbackQuery):
    await AdminActions.give_get_data.set()
    await call.message.answer("<b>Введите username/id нужного вам человека.</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) использовал команду #{call.data}")


@dp.message_handler(state=AdminActions.give_get_data, content_types=['text'])
async def give_balance_handler_sum(msg: types.Message, state: FSMContext):
    await state.update_data(username=msg.text)
    await msg.answer("<b>Введите сумму, которую хотите выдать:</b>", reply_markup=keyboard.cancel_inline())
    await AdminActions.give_get_sum.set()


@dp.message_handler(state=AdminActions.give_get_sum, content_types=['text'])
async def give_balance_handler_sum_next_step(msg: types.Message, state: FSMContext):
    data = await state.get_data()
    give_user = data['username']
    user = User(msg.from_user.id, msg.from_user.username)
    await user.add_balance(msg.text, give_user)
    await msg.answer(f"Вы выдали пользователю {give_user} {msg.text} рублей на баланс.")
    await state.finish()


@dp.callback_query_handler(text_contains="remove_balance")
async def remove_balance(call: types.CallbackQuery):
    await AdminActions.remove_get_data.set()
    await call.message.answer("<b>Введите username/id нужного вам человека.</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) использовал команду #{call.data}")


@dp.message_handler(state=AdminActions.remove_get_data, content_types=['text'])
async def remove_balance_handler_sum(msg: types.Message, state: FSMContext):
    await state.update_data(username=msg.text)
    await msg.answer("<b>Введите сумму, которую хотите списать:</b>", reply_markup=keyboard.cancel_inline())
    await AdminActions.remove_get_sum.set()


@dp.message_handler(state=AdminActions.remove_get_sum, content_types=['text'])
async def remove_balance_handler_sum_next_step(msg: types.Message, state: FSMContext):
    data = await state.get_data()
    give_user = data['username']
    user = User(msg.from_user.id, msg.from_user.username)
    await user.del_balance(msg.text, give_user)
    await msg.answer(f"Вы забрали у пользователя {give_user} {msg.text} рублей с баланса.")
    await state.finish()


@dp.callback_query_handler(text_contains="create_promo")
async def create_promo(call: types.CallbackQuery):
    await AdminActions.promo_name.set()
    await call.message.answer("<b>Введите промокод, который хотите создать:</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {call.from_user.username}({call.from_user.id}) использовал команду #{call.data}")


@dp.message_handler(state=AdminActions.promo_name, content_types=['text'])
async def create_promo_name(msg: types.Message, state: FSMContext):
    await state.update_data(promo_name=msg.text)
    await msg.answer(f"<b>Введите количество использований: </b>", reply_markup=keyboard.cancel_inline())
    await AdminActions.promo_activates.set()


@dp.message_handler(state=AdminActions.promo_activates, content_types=['text'])
async def create_promo_activates(msg: types.Message, state: FSMContext):
    await state.update_data(count_activates=msg.text)
    await msg.answer(f"<b>Введите сумму, которая начислится на баланс пользователя: </b>",
                     reply_markup=keyboard.cancel_inline())
    await AdminActions.promo_sum.set()


@dp.message_handler(state=AdminActions.promo_sum, content_types=['text'])
async def create_promo_sum(msg: types.Message, state: FSMContext):
    data = await state.get_data()
    count_activates = data['count_activates']
    promo_name = data['promo_name']
    await User(msg.from_user.id, msg.from_user.username).create_promo(promo_name, count_activates, msg.text)
    await msg.answer(
        f"<b>Промокод был создан!\n\nИнформация о промокоде:\n\nПромокод: <code>{promo_name}</code>\nКоличество активаций: {count_activates} шт.\nСумма: {msg.text} рублей</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="use_promo")
async def use_promo(call: types.CallbackQuery):
    await Promo.enter_promo.set()
    await call.message.answer("<b>Введите промокод:</b>", reply_markup=keyboard.cancel_inline())


def MonitoringStats():
    allWorker = GetAllWorker("database.db")
    context = (f"#stats {get_now()} #RavenSEO"
               f"📊 Статистика заказов\nДневная смена:")

    for i in allWorker:
        worker = Worker(int(i.id), i.username, "database.db")
        workerData = worker.GetData()

        order_completed_day = worker.GetOrderToDay("completed", "day")
        order_un_completed_day = worker.GetOrderToDay("uncompleted", "day")
        context += f"\n{workerData.username}({workerData.id}) Выполнено/отменено: {len(order_completed_day)}/{len(order_un_completed_day)}"

    context += "\n\nНочная смена:"
    for i in allWorker:
        worker = Worker(int(i.id), i.username, "database.db")
        workerData = worker.GetData()
        order_completed_night = worker.GetOrderToDay("completed", "night")
        order_un_completed_night = worker.GetOrderToDay("uncompleted", "night")
        context += f"\n{workerData.username}({workerData.id}) Выполнено/отменено: {len(order_completed_night)}/{len(order_un_completed_night)}"

    data = {
        "chat_id": config.log_order_channel,
        "text": context
    }
    response = requests.post(
        f'https://api.telegram.org/bot{config.bot_token}/sendMessage', data=data)


def runMonitoring():
    while True:
        schedule.run_pending()
        time.sleep(1000)


@dp.message_handler(state=Promo.enter_promo, content_types=['text'])
async def use_promo_get_promo(msg: types.Message, state: FSMContext):
    promo = msg.text
    promo_obj = await User(msg.from_user.id, msg.from_user.username).fetch_promo(promo)
    if promo_obj:
        if f"@{msg.from_user.username}" in str(promo_obj['used']).split(" "):
            await msg.answer("<b>Вы уже использовали этот промокод!</b>")
            await state.finish()
        else:
            if promo_obj['activates_expired'] >= 1:
                await User(msg.from_user.id, msg.from_user.username).use_promo(promo, '@' + msg.from_user.username)
                await User(msg.from_user.id, msg.from_user.username).add_balance(promo_obj['sum'], msg.from_user.id)
                await msg.answer(
                    f"<b>Вы успешно активировали данный промокод. На ваш баланс зачислено {promo_obj['sum']} рублей.</b>")
                await state.finish()
            else:
                await msg.answer(
                    "<b>Вы не можете использовать этот промокод, так как его использовали макс. количество раз!</b>")
                await state.finish()
    else:
        await msg.answer(
            "<b>Вы не можете использовать этот промокод, так как его не существует!</b>")
        await state.finish()


@dp.callback_query_handler(regexp=r"posting", state='*')
async def posting_get_msg(callback: types.CallbackQuery):
    await AdminActions.posting_msg.set()
    await callback.message.answer("<b>⚙️ Введите текст рыссылки:</b>", reply_markup=keyboard.cancel_inline())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) использовал команду #{callback.data}")


@dp.callback_query_handler(regexp=r"service_off", state='*')
async def service_off(callback: types.CallbackQuery):
    await User(callback.from_user.id, callback.from_user.username).set_status(1)
    msg_id = callback.message.message_id
    await bot.send_message(config.seo_queue,
                           "<b>🟢 Администратор в сети. Теперь снова можно отправлять заявки на SEO!</b>")
    await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.admin_panel_service_on())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) использовал команду #{callback.data}")


@dp.callback_query_handler(regexp=r"service_on", state='*')
async def service_on(callback: types.CallbackQuery):
    await User(callback.from_user.id, callback.from_user.username).set_status(0)
    msg_id = callback.message.message_id
    await bot.send_message(config.seo_queue,
                           "<b>🔴 Администратор не в сети. Заявки больше не принимаются!</b>")
    await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.admin_panel_service_off())
    await try_message(id=config.log_channel,
                      text=f"#RavenSEO Пользователь {callback.from_user.username}({callback.from_user.id}) использовал команду #{callback.data}")


@dp.message_handler(state=AdminActions.posting_msg, content_types=['text'])
async def post_method(msg: types.Message, state: FSMContext):
    text = msg.text
    users = await User(msg.from_user.id, msg.from_user.username).fetch_all()
    bot_banned = 0
    goods = 0
    await msg.answer("<b>Начинаю рассылку...</b>", reply_markup=keyboard.start_keyboard())
    for user in users:
        try:
            await bot.send_message(user['id'], text)
            goods += 1
        except:
            bot_banned += 1
    await msg.answer(
        f"<b>Рассылка завершена. Бота заблокировали: {bot_banned} чел. Успешно доставлено: {goods} сообщений</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="standart_movie")
async def standart_movie_handler(call: types.CallbackQuery):
    user = await User(call.from_user.id, call.from_user.username).fetch()
    if user['ban'] == 1:
        return await call.message.answer("<b>Вы заблокированы администратором!</b>")
    if user['balance'] < config.standart_price:
        return await call.message.answer("<b>Недостаточно средств! Пополните ваш баланс в профиле!</b>")
    await MovieCreator.standart_movie_get_task.set()
    await call.message.answer(
        f"<b>🤖 Напоминаем, что данная услуга стоит {config.standart_price} рублей, которые спишутся с вашего баланса!\n\nОпишите ваш заказ:</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=MovieCreator.standart_movie_get_task, content_types=['text'])
async def standart_movie_handler_msg(msg: types.Message, state: FSMContext):
    task = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    await user.create_movie_order(f"@{msg.from_user.username}", task, 1)
    order = await user.fetch_movie_order_by_url(task)
    order_id = order['id']
    await bot.send_message(config.movie_chat_id,
                           f"""
<i>Заявка №{order_id}</i>
<b>📢 Новая заявка на <i>(STANDART)</i> от @{msg.from_user.username}!

💬 Описание задачи: {task}</b>""", reply_markup=keyboard.movie_request(msg.from_user.id, order_id, 1))
    await user.del_balance(config.standart_price, msg.from_user.id)
    await msg.answer(
        f"<b>😋 Отлично, ваше задание:\n\n<i>{task}</i>\n\nВаша заявка была отправлена на рассмотрение!</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="preview")
async def preview_movie_handler(call: types.CallbackQuery):
    user = await User(call.from_user.id, call.from_user.username).fetch()
    if user['ban'] == 1:
        return await call.message.answer("<b>Вы заблокированы администратором!</b>")
    if user['balance'] < config.preview_price:
        return await call.message.answer("<b>Недостаточно средств! Пополните ваш баланс в профиле!</b>")
    await MovieCreator.preview_get_task.set()
    await call.message.answer(
        f"<b>🤖 Напоминаем, что данная услуга стоит {config.preview_price} рублей, которые спишутся с вашего баланса!\n\nОпишите ваш заказ:</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=MovieCreator.preview_get_task, content_types=['text'])
async def preview_movie_handler_msg(msg: types.Message, state: FSMContext):
    task = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    await user.create_movie_order(f"@{msg.from_user.username}", task, 3)
    order = await user.fetch_movie_order_by_url(task)
    order_id = order['id']
    await bot.send_message(config.movie_chat_id,
                           f"""
<i>Заявка №{order_id}</i>
<b>📢 Новая заявка на <i>(PREVIEW)</i> от @{msg.from_user.username}!

💬 Описание задачи: {task}</b>""", reply_markup=keyboard.movie_request(msg.from_user.id, order_id, 3))
    await user.del_balance(config.preview_price, msg.from_user.id)
    await msg.answer(
        f"<b>😋 Отлично, ваше задание:\n\n<i>{task}</i>\n\nВаша заявка была отправлена на рассмотрение!</b>")
    await state.finish()


@dp.callback_query_handler(text_contains="fake_soft_movie")
async def fake_soft_movie_handler(call: types.CallbackQuery):
    user = await User(call.from_user.id, call.from_user.username).fetch()
    if user['ban'] == 1:
        return await call.message.answer("<b>Вы заблокированы администратором!</b>")
    if user['balance'] < config.fake_soft_price:
        return await call.message.answer("<b>Недостаточно средств! Пополните ваш баланс в профиле!</b>")
    await MovieCreator.fake_soft_movie_get_task.set()
    await call.message.answer(
        f"<b>🤖 Напоминаем, что данная услуга стоит {config.fake_soft_price} рублей, которые спишутся с вашего баланса!\n\nОпишите ваш заказ:</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=MovieCreator.fake_soft_movie_get_task, content_types=['text'])
async def fake_soft_movie_handler_msg(msg: types.Message, state: FSMContext):
    task = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    await user.create_movie_order(f"@{msg.from_user.username}", task, 2)
    order = await user.fetch_movie_order_by_url(task)
    order_id = order['id']
    await bot.send_message(config.movie_chat_id,
                           f"""
<i>Заявка №{order_id}</i>
<b>📢 Новая заявка на <i>(FAKE SOFT)</i> от @{msg.from_user.username}!

💬 Описание задачи: {task}</b>""", reply_markup=keyboard.movie_request(msg.from_user.id, order_id, 2))
    await user.del_balance(config.fake_soft_price, msg.from_user.id)
    await msg.answer(
        f"<b>😋 Отлично, ваше задание:\n\n<i>{task}</i>\n\nВаша заявка была отправлена на рассмотрение!</b>")
    await state.finish()


@dp.message_handler(state=SMMPanel.get_views_link, content_types=['text'])
async def get_views_link(msg: types.Message, state: FSMContext):
    link = msg.text
    await state.update_data(link=link)
    await SMMPanel.get_views_count.set()
    await msg.answer(
        "<b>👁 Отправьте нужное количество просмотров:\n\nМинимальное количество - 100 шт.\nМаксимальное - 500 шт.</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=SMMPanel.get_views_count, content_types=['text'])
async def check_views_order(msg: types.Message, state: FSMContext):
    try:
        data = await state.get_data()
        link = data['link']
        count = int(msg.text)
        payment_sum = 0
        if 99 < count < 501:
            payment_sum += 0.03679 * count + 0.03679 * count * 0.2
            if 'watch' in link:
                link = "https://youtu.be/" + link.split("v=")[-1]
            await msg.answer(
                f"<b>⚙️ Информация о вашем заказе:\n\n🔗 Ссылка на видеоролик: {link}\n👁 Количество просмотров: {count}\n\nСтоимость данной услуги - бесплатно\nЖелаете продолжить?</b>",
                reply_markup=keyboard.views_accept(link, count, round(payment_sum, 1)), disable_web_page_preview=True)
            await state.finish()
        elif count > 500:
            await msg.answer("<b>Количество просмотров превышает максимальное значение - <code>500</code> шт.</b>")
            await state.finish()
        elif count < 100:
            await msg.answer("<b>Количество просмотров ниже минимального значения - <code>100</code> шт.</b>")
            await state.finish()

    except Exception as ex:
        print(ex)
        await state.finish()
        await msg.answer("<b>Произошла ошибка.</b>")


@dp.callback_query_handler(regexp=r"views_accept\|(.+)\|(.+)\|(.+)\|(.+)", state='*')
async def views_accept_handler(callback: types.CallbackQuery):
    data = callback.data.split("|")
    link = data[1]
    count = data[2]
    status = data[4]
    if status == 'yes':
        cosmo_panel.create_views_order(count, link)
        msg_id = callback.message.message_id
        await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.likes_accept_yes())
        await callback.message.answer(f"<b>Ваша заявка находится в работе, спасибо за заказ!</b>")

    elif status == 'no':
        msg_id = callback.message.message_id
        await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.likes_accept_no())
        await callback.message.answer("<b>Ваш заказ был отменён!</b>")


@dp.message_handler(state=SMMPanel.get_likes_link, content_types=['text'])
async def get_likes_link(msg: types.Message, state: FSMContext):
    link = msg.text
    await state.update_data(link=link)
    await SMMPanel.get_likes_count.set()
    await msg.answer(
        "<b>❤️ Отправьте нужное количество лайков:\n\nМинимальное количество - 10 шт.\nМаксимальное - 1000 шт.</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=SMMPanel.get_likes_count, content_types=['text'])
async def check_likes_order(msg: types.Message, state: FSMContext):
    try:
        data = await state.get_data()
        link = data['link']
        count = int(msg.text)
        payment_sum = 0
        if 9 < count < 1001:
            payment_sum += 0.03679 * count + 0.03679 * count * 0.2
            if 'watch' in link:
                link = "https://youtu.be/" + link.split("v=")[-1]
            await msg.answer(
                f"<b>⚙️ Информация о вашем заказе:\n\n🔗 Ссылка на видеоролик: {link}\n❤️ Количество лайков: {count}\n\nСтоимость данной услуги - бесплатно\nЖелаете продолжить?</b>",
                reply_markup=keyboard.likes_accept(link, count, round(payment_sum, 1)), disable_web_page_preview=True)
            await state.finish()
        elif count > 1000:
            await msg.answer("<b>Количество лайков превышает максимальное значение - <code>1000</code> лайков.</b>")
            await state.finish()
        elif count < 10:
            await msg.answer("<b>Количество лайков ниже минимального значения - <code>10</code> лайков.</b>")
            await state.finish()

    except Exception as ex:
        print(ex)
        await state.finish()
        await msg.answer("<b>Произошла ошибка.</b>")


@dp.callback_query_handler(regexp=r"likes_accept\|(.+)\|(.+)\|(.+)\|(.+)", state='*')
async def likes_accept_handler(callback: types.CallbackQuery):
    data = callback.data.split("|")
    link = data[1]
    count = data[2]
    payment_sum = float(data[3])
    status = data[4]
    if status == 'yes':
        user = User(callback.from_user.id, callback.from_user.username)
        cosmo_panel.create_likes_order(count, link)
        msg_id = callback.message.message_id
        await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.likes_accept_yes())
        await callback.message.answer(f"<b>Ваша заявка находится в работе, спасибо за заказ!</b>")

    elif status == 'no':
        msg_id = callback.message.message_id
        await bot.edit_message_reply_markup(callback.from_user.id, msg_id, reply_markup=keyboard.likes_accept_no())
        await callback.message.answer("<b>Ваш заказ был отменён!</b>")


@dp.message_handler(state=SMMPanel.get_comms_link, content_types=['text'])
async def get_comms_link(msg: types.Message, state: FSMContext):
    link = msg.text
    await state.update_data(link=link)
    await SMMPanel.get_comms.set()
    await msg.answer(
        "<b>💬 Отправьте комментарии одним сообщением:\n\nКомментарии должны быть разделены между собой запятыми, к примеру: <code>good video!, tnx so good, hello i am your sub!</code>\nМаксимальное количество - 100 шт.\nМинимальное - 5 шт.</b>",
        reply_markup=keyboard.cancel_inline())


@dp.message_handler(state=SMMPanel.get_comms, content_types=['text'])
async def get_comms(msg: types.Message, state: FSMContext):
    try:
        comms_list = msg.text.split(",")
        index = 0
        for i in comms_list:
            comms_list[index] = i.strip()
            index += 1
        comms = "\n".join(comms_list)
        data = await state.get_data()
        link = data['link']
        payment_sum = 0
        if 4 < len(comms_list) < 101:
            payment_sum += 0.30488 * len(comms_list) + 0.30488 * len(comms_list) * 0.2
            if 'watch' in link:
                link = "https://youtu.be/" + link.split("v=")[-1]
            cosmo_panel.create_comms_order(comms, link)
            await msg.answer(
                f"<b>⚙️ Информация о вашем заказе:\n\n🔗 Ссылка на видеоролик: {link}\n💬 Количество комментариев: {len(comms_list)}\n💬 Список комментариев: {', '.join(comms_list)}\n\nСтоимость данной услуги - бесплатно.</b>",
                disable_web_page_preview=True)
            await state.finish()

        elif len(comms_list) > 100:
            await msg.answer(
                "<b>Количество комментариев превышает максимальное значение - <code>100</code> комментариев.</b>")
            await state.finish()
        elif len(comms_list) < 5:
            await msg.answer("<b>Количество комментариев ниже минимального значения - <code>5</code> комментариев.</b>")
            await state.finish()

    except Exception as ex:
        print(ex)
        await state.finish()
        await msg.answer("<b>Произошла ошибка.</b>")


@dp.message_handler(state=LinkChannel.get_channel, content_types=['text'])
async def link_get_channel(msg: types.Message, state: FSMContext):
    link = msg.text
    user = User(msg.from_user.id, msg.from_user.username)
    user_data = await user.fetch()
    if user_data['balance'] < config.link_price:
        await msg.answer(f"<b>Недостаточно средств. Стоимость услуги - {config.link_price}</b>")
        await state.finish()
    else:
        await bot.send_message(config.link_chat_id, f"""
<b>📢 Новая заявка на вязку каналов от @{msg.from_user.username}!

🔗 Ссылка на загрузку канала: {link}</b>
""", reply_markup=keyboard.link_request(msg.from_user.id))
        await user.del_balance(config.link_price, msg.from_user.id)
        await msg.answer(
            f"<b>Вы отправили заявку на вяз канала. С вашего баланса будет списано {config.link_price} рублей.</b>")
        await state.finish()


@dp.callback_query_handler(regexp=r"link_request\|(.+)\|(.+)", state='*')
async def update_link_callback(callback: types.CallbackQuery):
    data = callback.data.split("|")
    user_id = data[1]
    status = data[2]
    user = User(callback.from_user.id, callback.from_user.username)
    if status == 'ok':
        await bot.send_message(user_id, f"""
<b>Ваша заявка на вязку канала одобрена!

📋 Информация о заявке: 

⚙️ Статус: Одобрено ✅
</b>
""", disable_web_page_preview=True)
        await bot.edit_message_reply_markup(config.link_chat_id, callback.message.message_id,
                                            reply_markup=keyboard.link_request_next_step(user_id))
    elif status == 'fail':
        await user.add_balance(config.link_price, user_id)
        await bot.send_message(user_id, f"""
<b>Ваша заявка на вязку канала отклонена!
💳Деньги возвращены на ваш баланс!

📋 Информация о заявке: 

⚙️ Статус: Отклонено ❌
</b>""", disable_web_page_preview=True)
        await bot.edit_message_reply_markup(config.link_chat_id, callback.message.message_id,
                                            reply_markup=keyboard.link_request_failed(
                                                f"@{callback.from_user.username}"))


@dp.callback_query_handler(regexp=r"link_request_next_step\|(.+)\|(.+)", state='*')
async def update_seo_callback_next_step(callback: types.CallbackQuery):
    data = callback.data.split("|")
    user_id = data[1]
    status = data[2]
    user = User(callback.from_user.id, callback.from_user.username)
    if status == 'ok':
        await bot.send_message(user_id, f"""
<b>Ваша заявка на вязку канала завершена!

📋 Информация о заявке: 

⚙️ Статус: Выполнено ✅

😊 Отставь пожалуйста отзыв: https://zelenka.guru/threads//
</b>
    """, disable_web_page_preview=True)
        await bot.edit_message_reply_markup(config.link_chat_id, callback.message.message_id,
                                            reply_markup=keyboard.link_request_finished(
                                                f"@{callback.from_user.username}"))
    elif status == 'fail':
        await user.add_balance(config.link_price, user_id)
        await bot.send_message(user_id, f"""
<b>Ваша заявка на вязку канала отклонена!
💳Деньги возвращены на ваш баланс!

📋 Информация о заявке: 

⚙️ Статус: Отклонено ❌</b>""", disable_web_page_preview=True)
        await bot.edit_message_reply_markup(config.link_chat_id, callback.message.message_id,
                                            reply_markup=keyboard.link_request_failed(
                                                f"@{callback.from_user.username}"))


if __name__ == "__main__":
    schedule.every().day.at("23:00").do(MonitoringStats)
    threading.Thread(target=runMonitoring).start()
    MonitoringStats()
    dp.loop.create_task(set_admin(config.admin))
    executor.start_polling(dp)
