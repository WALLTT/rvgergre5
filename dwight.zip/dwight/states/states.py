from aiogram.dispatcher.filters.state import StatesGroup, State


class SeoChecker(StatesGroup):
    get_url = State()


class SeoRequest(StatesGroup):
    get_url = State()


class CrystalMethod(StatesGroup):
    get_sum = State()


class QiwiMethod(StatesGroup):
    get_sum = State()


class AdminActions(StatesGroup):
    ban_get_data = State()
    unban_get_data = State()
    give_get_data = State()
    give_get_sum = State()
    remove_get_data = State()
    remove_get_sum = State()
    promo_name = State()
    promo_activates = State()
    promo_sum = State()
    posting_msg = State()


class Promo(StatesGroup):
    enter_promo = State()


class MovieCreator(StatesGroup):
    standart_movie_get_task = State()
    fake_soft_movie_get_task = State()
    preview_get_task = State()


class SMMPanel(StatesGroup):
    get_likes_link = State()
    get_likes_count = State()
    get_comms_link = State()
    get_comms = State()
    get_views_link = State()
    get_views_count = State()

class LinkChannel(StatesGroup):
    get_channel = State()