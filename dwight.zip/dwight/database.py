import aiosqlite
from typing import Optional, Union
import os
import asyncio


class Database:
    PATH = os.path.abspath("database.db")

    def __init__(self, filename: Optional[str] = None, loop: asyncio.BaseEventLoop = asyncio.get_event_loop()):
        self.__database = filename or self.PATH
        self.__loop = loop
        self._con: Optional[aiosqlite.Connection] = loop.run_until_complete(self._connect())

    async def _connect(self):
        _con = await aiosqlite.connect(self.__database)
        _con.row_factory = aiosqlite.Row
        print('Connected to database. Path: %s' % self.__database)
        return _con

    async def execute(self, query: str, *option: Union[str, int, float]):
        cursor = await self._con.cursor()
        await cursor.execute(query, option)
        await self._con.commit()
        await cursor.close()

    async def fetch(self, query: str, *option: Union[str, int, float]) -> Union[dict, None]:
        cursor = await self._con.cursor()
        await cursor.execute(query, option)
        result = await cursor.fetchone()
        await cursor.close()
        return dict(result) if result else None

    async def fetch_all(self, query: str, *option: Union[str, int, float]) -> list:
        cursor = await self._con.cursor()
        await cursor.execute(query, option)
        result = await cursor.fetchall()
        await cursor.close()
        return [dict(el) for el in result]

    async def CreateTable(self, request):
        try:

            cursor = await self._con.cursor()
            await cursor.execute(request)
            await self._con.commit()
            print("Таблица SQLite создана")


        except aiosqlite.Error as error:

            pass
